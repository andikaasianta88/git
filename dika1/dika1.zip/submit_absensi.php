<?php

$host = 'cloud.hypercloudhost.com';
$db = 'ppexbjum_smk06';
$user = 'ppexbjum_dika06';
$pass = 'f],J?7TUVT5T';

$conn = new mysqli($host, $user, $pass, $db, 3306);


if($conn->connect_error){
    die("conection failed:".$conn->connect_error);
}

$nisn =$_POST['nisn'];
$status =$_POST['status'];
$date =date('y-m-d');

$sql ="INSERT INTO absensi (nisn,id_absen,tanggal_absensi)VALUES('$nisn','$status','$date')";

if($conn->query($sql)===TRUE){
  header ("location:index.php");
}else{
    echo"error:".$sql."<br>".$conn->error;
}
$conn->close();
?>                                                                                           